# Edition #002
## Stop Writing Promotional Emails. Build an AI Agent That Does It For You.

This project demonstrates how to build an AI-powered promotional email automation workflow that reads customer purchase data, reviews category-based discounts, creates a personalized email body, and sends the message automatically.

## Project Structure

```text
Edition-002-PromoMail-AI-Agent
├── flow-json/
│   └── sanitized-workflow.json
├── flow-export/
│   └── Edition-002-PromoMail-AI-Agent-sanitized-reference.zip
├── sample-data/
│   ├── Customers.csv
│   └── ProductDiscounts.csv
├── screenshots/
│   └── workflow.png
├── prompts/
│   └── ai-email-prompt.txt
└── README.md
```

## Workflow

1. Run the automation monthly.
2. Get customer purchase data.
3. Get active product discounts.
4. Process each customer.
5. Match discounts by product category.
6. Build a discount summary.
7. Generate a personalized promotional email body with AI.
8. Send the email.
9. Reset the discount summary for the next customer.

## Privacy Note

The shared workflow files are sanitized. Replace placeholder values such as `YOUR_SHAREPOINT_SITE_URL`, `CUSTOMERS_LIST_ID`, `PRODUCT_DISCOUNTS_LIST_ID`, and `YOUR_AI_PROMPT_ID` with your own environment values before using the workflow.
